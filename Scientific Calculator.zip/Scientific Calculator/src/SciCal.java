
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.CubicCurve2D;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.*;
import javax.swing.text.DefaultCaret;
import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
//left and right, abs, sin, cos, tan, x2, x^, log, log a, ln, M+, off
public class SciCal implements ActionListener, MouseListener, KeyListener {
	Background background;
	JButton shift, alpha, arrowUp, arrowDown, arrowLeft, arrowRight, mode, on,
			abs, xCube, xInverse, logStat, fraction, squareroot, square,
			exponentInput, log, naturalLog, negative, degrees, hyp, sin, cos,
			tan, RCL, eng, openP, closeP, sToD, mPlus, seven, eight, nine, del,
			ac, four, five, six, times, divide, one, two, three, plus, minus,
			zero, decimal, baseTen, ans, equals, hideCover, solarPanel;
	JTextArea text, text2;
	JTextField text3, text4;
	JFrame frame;
	String answer;
	String memory = "0";
	boolean checker = false;
	boolean isOn = false;
	boolean isZero = false;
	boolean isShift = false;
	boolean isAlpha = false;
	
	public JPanel setButtons() {

		JPanel pane = new JPanel();
		pane.setFocusable(false);
		pane.setPreferredSize(new Dimension(365, 702));
		pane.setLayout(null);
		hideCover = new JButton("Show/Hide Cover");
		hideCover.setBounds(0, 0, 120, 19);
		hideCover.setBorder(null);
		pane.add(hideCover);

		ImageIcon solarPanelIcon = new ImageIcon(getClass().getResource("/images/solarPanel.jpg"));
		solarPanel = new JButton(solarPanelIcon);
		solarPanel.setBorder(null);
		solarPanel.setBounds(175, 47, 138, 48);
		solarPanel.setFocusable(false);
		pane.add(solarPanel);

		ImageIcon shiftIcon = new ImageIcon(getClass().getResource("/images/shift.png"));
		ImageIcon shiftIcon2 = new ImageIcon(getClass().getResource("/images/shift2.png"));
		shift = new JButton(shiftIcon);
		shift.setBorder(null);
		shift.setPressedIcon(shiftIcon2);
		shift.setBounds(45, 272, 40, 25);
		shift.setFocusable(false);
		pane.add(shift);

		ImageIcon alphaIcon = new ImageIcon(getClass().getResource("/images/alpha.png"));
		ImageIcon alphaIcon2 = new ImageIcon(getClass().getResource("/images/alpha2.png"));
		alpha = new JButton(alphaIcon);
		alpha.setBorder(null);
		alpha.setPressedIcon(alphaIcon2);
		alpha.setBounds(93, 277, 40, 25);
		alpha.setFocusable(false);
		pane.add(alpha);

		ImageIcon arrowUpIcon = new ImageIcon(getClass().getResource("/images/arrowUp.png"));
		ImageIcon arrowUpIcon2 = new ImageIcon(getClass().getResource("/images/arrowUp2.png"));
		arrowUp = new JButton(arrowUpIcon);
		arrowUp.setBorder(null);
		arrowUp.setPressedIcon(arrowUpIcon2);
		arrowUp.setBounds(165, 266, 40, 25);
		arrowUp.setFocusable(false);
		pane.add(arrowUp);

		ImageIcon arrowLeftIcon = new ImageIcon(getClass().getResource("/images/arrowLeft.png"));
		ImageIcon arrowLeftIcon2 = new ImageIcon(getClass().getResource("/images/arrowLeft2.png"));
		arrowLeft = new JButton(arrowLeftIcon);
		arrowLeft.setBorder(null);
		arrowLeft.setPressedIcon(arrowLeftIcon2);
		arrowLeft.setBounds(147, 286, 20, 45);
		arrowLeft.setFocusable(false);
		pane.add(arrowLeft);

		ImageIcon arrowRightIcon = new ImageIcon(getClass().getResource("/images/arrowRight.png"));
		ImageIcon arrowRightIcon2 = new ImageIcon(getClass().getResource("/images/arrowRight2.png"));
		arrowRight = new JButton(arrowRightIcon);
		arrowRight.setBorder(null);
		arrowRight.setPressedIcon(arrowRightIcon2);
		arrowRight.setBounds(208, 285, 20, 45);
		arrowRight.setFocusable(false);
		pane.add(arrowRight);

		ImageIcon arrowDownIcon = new ImageIcon(getClass().getResource("/images/arrowDown.png"));
		ImageIcon arrowDownIcon2 = new ImageIcon(getClass().getResource("/images/arrowDown2.png"));
		arrowDown = new JButton(arrowDownIcon);
		arrowDown.setBorder(null);
		arrowDown.setPressedIcon(arrowDownIcon2);
		arrowDown.setBounds(167, 326, 40, 22);
		arrowDown.setFocusable(false);
		pane.add(arrowDown);

		ImageIcon modeIcon = new ImageIcon(getClass().getResource("/images/mode.png"));
		ImageIcon modeIcon2 =new ImageIcon(getClass().getResource("/images/mode2.png"));
		mode = new JButton(modeIcon);
		mode.setBorder(null);
		mode.setPressedIcon(modeIcon2);
		mode.setBounds(242, 278, 40, 25);
		mode.setFocusable(false);
		pane.add(mode);

		ImageIcon onIcon = new ImageIcon(getClass().getResource("/images/on.png"));
		ImageIcon onIcon2 = new ImageIcon(getClass().getResource("/images/on2.png"));
		on = new JButton(onIcon);
		on.setBorder(null);
		on.setPressedIcon(onIcon2);
		on.setBounds(290, 273, 40, 25);
		on.setFocusable(false);
		pane.add(on);

		ImageIcon absIcon = new ImageIcon(getClass().getResource("/images/abs.png"));
		ImageIcon absIcon2 = new ImageIcon(getClass().getResource("/images/abs2.png"));
		abs = new JButton(absIcon);
		abs.setBorder(null);
		abs.setPressedIcon(absIcon2);
		abs.setBounds(53, 326, 40, 25);
		abs.setFocusable(false);
		pane.add(abs);

		ImageIcon xCubeIcon = new ImageIcon(getClass().getResource("/images/xCube.png"));
		ImageIcon xCubeIcon2 = new ImageIcon(getClass().getResource("/images/xCube2.png"));
		xCube = new JButton(xCubeIcon);
		xCube.setBorder(null);
		xCube.setPressedIcon(xCubeIcon2);
		xCube.setBounds(99, 326, 40, 25);
		xCube.setFocusable(false);
		pane.add(xCube);

		ImageIcon xInverseIcon = new ImageIcon(getClass().getResource("/images/xInverse.png"));
		ImageIcon xInverseIcon2 = new ImageIcon(getClass().getResource("/images/xInverse2.png"));
		xInverse = new JButton(xInverseIcon);
		xInverse.setBorder(null);
		xInverse.setPressedIcon(xInverseIcon2);
		xInverse.setBounds(239, 327, 40, 25);
		xInverse.setFocusable(false);
		pane.add(xInverse);

		ImageIcon logStatIcon = new ImageIcon(getClass().getResource("/images/logStat.png"));
		ImageIcon logStatIcon2 = new ImageIcon(getClass().getResource("/images/logStat2.png"));
		logStat = new JButton(logStatIcon);
		logStat.setBorder(null);
		logStat.setPressedIcon(logStatIcon2);
		logStat.setBounds(285, 327, 40, 25);
		logStat.setFocusable(false);
		pane.add(logStat);

		ImageIcon fractionIcon = new ImageIcon(getClass().getResource("/images/fraction.png"));
		ImageIcon fractionIcon2 = new ImageIcon(getClass().getResource("/images/fraction2.png"));
		fraction = new JButton(fractionIcon);
		fraction.setBorder(null);
		fraction.setPressedIcon(fractionIcon2);
		fraction.setBounds(52, 367, 40, 25);
		fraction.setFocusable(false);
		pane.add(fraction);

		ImageIcon squarerootIcon = new ImageIcon(getClass().getResource("/images/squareroot.png"));
		ImageIcon squarerootIcon2 = new ImageIcon(getClass().getResource("/images/squareroot2.png"));
		squareroot = new JButton(squarerootIcon);
		squareroot.setBorder(null);
		squareroot.setPressedIcon(squarerootIcon2);
		squareroot.setBounds(98, 367, 40, 25);
		squareroot.setFocusable(false);
		pane.add(squareroot);

		ImageIcon squareIcon = new ImageIcon(getClass().getResource("/images/square.png"));
		ImageIcon squareIcon2 = new ImageIcon(getClass().getResource("/images/square2.png"));
		square = new JButton(squareIcon);
		square.setBorder(null);
		square.setPressedIcon(squareIcon2);
		square.setBounds(144, 367, 40, 25);
		square.setFocusable(false);
		pane.add(square);

		ImageIcon exponentInputIcon = new ImageIcon(getClass().getResource("/images/exponentInput.png"));
		ImageIcon exponentInputIcon2 = new ImageIcon(getClass().getResource("/images/exponentInput2.png"));
		exponentInput = new JButton(exponentInputIcon);
		exponentInput.setBorder(null);
		exponentInput.setPressedIcon(exponentInputIcon2);
		exponentInput.setBounds(190, 367, 40, 25);
		exponentInput.setFocusable(false);
		pane.add(exponentInput);

		ImageIcon logIcon = new ImageIcon(getClass().getResource("/images/log.png"));
		ImageIcon logIcon2 = new ImageIcon(getClass().getResource("/images/log2.png"));
		log = new JButton(logIcon);
		log.setBorder(null);
		log.setPressedIcon(logIcon2);
		log.setBounds(236, 367, 40, 25);
		log.setFocusable(false);
		pane.add(log);

		ImageIcon NaturalLogIcon = new ImageIcon(getClass().getResource("/images/naturalLog.png"));
		ImageIcon NaturalLogIcon2 = new ImageIcon(getClass().getResource("/images/naturalLog2.png"));
		naturalLog = new JButton(NaturalLogIcon);
		naturalLog.setBorder(null);
		naturalLog.setPressedIcon(NaturalLogIcon2);
		naturalLog.setBounds(282, 367, 40, 25);
		naturalLog.setFocusable(false);
		pane.add(naturalLog);

		ImageIcon negativeIcon = new ImageIcon(getClass().getResource("/images/negative.png"));
		ImageIcon negativeIcon2 = new ImageIcon(getClass().getResource("/images/negative2.png"));
		negative = new JButton(negativeIcon);
		negative.setBorder(null);
		negative.setPressedIcon(negativeIcon2);
		negative.setBounds(52, 405, 40, 25);
		negative.setFocusable(false);
		pane.add(negative);

		ImageIcon degreeIcon = new ImageIcon(getClass().getResource("/images/degree.png"));
		ImageIcon degreeIcon2 = new ImageIcon(getClass().getResource("/images/degree2.png"));
		degrees = new JButton(degreeIcon);
		degrees.setBorder(null);
		degrees.setPressedIcon(degreeIcon2);
		degrees.setBounds(98, 405, 40, 25);
		degrees.setFocusable(false);
		pane.add(degrees);

		ImageIcon hypIcon = new ImageIcon(getClass().getResource("/images/hyp.png"));
		ImageIcon hypIcon2 = new ImageIcon(getClass().getResource("/images/hyp2.png"));
		hyp = new JButton(hypIcon);
		hyp.setBorder(null);
		hyp.setPressedIcon(hypIcon2);
		hyp.setBounds(144, 405, 40, 25);
		hyp.setFocusable(false);
		pane.add(hyp);

		ImageIcon sinIcon = new ImageIcon(getClass().getResource("/images/sin.png"));
		ImageIcon sinIcon2 = new ImageIcon(getClass().getResource("/images/sin2.png"));
		sin = new JButton(sinIcon);
		sin.setBorder(null);
		sin.setPressedIcon(sinIcon2);
		sin.setBounds(190, 405, 40, 25);
		sin.setFocusable(false);
		pane.add(sin);

		ImageIcon cosIcon = new ImageIcon(getClass().getResource("/images/cos.png"));
		ImageIcon cosIcon2 = new ImageIcon(getClass().getResource("/images/cos2.png"));
		cos = new JButton(cosIcon);
		cos.setBorder(null);
		cos.setPressedIcon(cosIcon2);
		cos.setBounds(238, 405, 40, 25);
		cos.setFocusable(false);
		pane.add(cos);

		ImageIcon tanIcon = new ImageIcon(getClass().getResource("/images/tan.png"));
		ImageIcon tanIcon2 = new ImageIcon(getClass().getResource("/images/tan2.png"));
		tan = new JButton(tanIcon);
		tan.setBorder(null);
		tan.setPressedIcon(tanIcon2);
		tan.setBounds(284, 407, 40, 25);
		tan.setFocusable(false);
		pane.add(tan);

		ImageIcon rclIcon = new ImageIcon(getClass().getResource("/images/rcl.png"));
		ImageIcon rclIcon2 = new ImageIcon(getClass().getResource("/images/rcl2.png"));
		RCL = new JButton(rclIcon);
		RCL.setBorder(null);
		RCL.setPressedIcon(rclIcon2);
		RCL.setBounds(51, 444, 40, 25);
		RCL.setFocusable(false);
		pane.add(RCL);

		ImageIcon engIcon = new ImageIcon(getClass().getResource("/images/eng.png"));
		ImageIcon engIcon2 = new ImageIcon(getClass().getResource("/images/eng2.png"));
		eng = new JButton(engIcon);
		eng.setBorder(null);
		eng.setPressedIcon(engIcon2);
		eng.setBounds(97, 446, 40, 25);
		eng.setFocusable(false);
		pane.add(eng);

		ImageIcon openPIcon = new ImageIcon(getClass().getResource("/images/openP.png"));
		ImageIcon openPIcon2 = new ImageIcon(getClass().getResource("/images/openP2.png"));
		openP = new JButton(openPIcon);
		openP.setBorder(null);
		openP.setPressedIcon(openPIcon2);
		openP.setBounds(144, 446, 40, 25);
		openP.setFocusable(false);
		pane.add(openP);

		ImageIcon closePIcon = new ImageIcon(getClass().getResource("/images/closeP.png"));
		ImageIcon closePIcon2 = new ImageIcon(getClass().getResource("/images/closeP2.png"));
		closeP = new JButton(closePIcon);
		closeP.setBorder(null);
		closeP.setPressedIcon(closePIcon2);
		closeP.setBounds(190, 446, 40, 25);
		closeP.setFocusable(false);
		pane.add(closeP);

		ImageIcon sToDIcon = new ImageIcon(getClass().getResource("/images/sToD.png"));
		ImageIcon sToDIcon2 = new ImageIcon(getClass().getResource("/images/sToD2.png"));
		sToD = new JButton(sToDIcon);
		sToD.setBorder(null);
		sToD.setPressedIcon(sToDIcon2);
		sToD.setBounds(236, 448, 40, 25);
		sToD.setFocusable(false);
		pane.add(sToD);

		ImageIcon mPlusIcon = new ImageIcon(getClass().getResource("/images/mPlus.png"));
		ImageIcon mPlusIcon2 = new ImageIcon(getClass().getResource("/images/mPlus2.png"));
		mPlus = new JButton(mPlusIcon);
		mPlus.setBorder(null);
		mPlus.setPressedIcon(mPlusIcon2);
		mPlus.setBounds(282, 446, 40, 25);
		mPlus.setFocusable(false);
		pane.add(mPlus);

		ImageIcon sevenIcon = new ImageIcon(getClass().getResource("/images/seven.png"));
		ImageIcon sevenIcon2 = new ImageIcon(getClass().getResource("/images/seven2.png"));
		seven = new JButton(sevenIcon);
		seven.setBorder(null);
		seven.setPressedIcon(sevenIcon2);
		seven.setBounds(50, 488, 50, 35);
		seven.setFocusable(false);
		pane.add(seven);

		ImageIcon eightIcon = new ImageIcon(getClass().getResource("/images/eight.png"));
		ImageIcon eightIcon2 = new ImageIcon(getClass().getResource("/images/eight2.png"));
		eight = new JButton(eightIcon);
		eight.setBorder(null);
		eight.setPressedIcon(eightIcon2);
		eight.setBounds(106, 488, 50, 35);
		eight.setFocusable(false);
		pane.add(eight);

		ImageIcon nineIcon = new ImageIcon(getClass().getResource("/images/nine.png"));
		ImageIcon nineIcon2 = new ImageIcon(getClass().getResource("/images/nine2.png"));
		nine = new JButton(nineIcon);
		nine.setBorder(null);
		nine.setPressedIcon(nineIcon2);
		nine.setBounds(162, 488, 50, 35);
		nine.setFocusable(false);
		pane.add(nine);

		ImageIcon delIcon = new ImageIcon(getClass().getResource("/images/del.png"));
		ImageIcon delIcon2 = new ImageIcon(getClass().getResource("/images/del2.png"));
		del = new JButton(delIcon);
		del.setBorder(null);
		del.setPressedIcon(delIcon2);
		del.setBounds(218, 488, 50, 35);
		del.setFocusable(false);
		pane.add(del);

		ImageIcon acIcon = new ImageIcon(getClass().getResource("/images/ac.png"));
		ImageIcon acIcon2 =new ImageIcon(getClass().getResource("/images/ac2.png"));
		ac = new JButton(acIcon);
		ac.setBorder(null);
		ac.setPressedIcon(acIcon2);
		ac.setBounds(274, 490, 50, 35);
		ac.setFocusable(false);
		pane.add(ac);

		ImageIcon fourIcon = new ImageIcon(getClass().getResource("/images/four.png"));
		ImageIcon fourIcon2 = new ImageIcon(getClass().getResource("/images/four2.png"));
		four = new JButton(fourIcon);
		four.setBorder(null);
		four.setPressedIcon(fourIcon2);
		four.setBounds(49, 535, 50, 35);
		four.setFocusable(false);
		pane.add(four);

		ImageIcon fiveIcon = new ImageIcon(getClass().getResource("/images/five.png"));
		ImageIcon fiveIcon2 = new ImageIcon(getClass().getResource("/images/five2.png"));
		five = new JButton(fiveIcon);
		five.setBorder(null);
		five.setPressedIcon(fiveIcon2);
		five.setBounds(105, 535, 49, 35);
		five.setFocusable(false);
		pane.add(five);

		ImageIcon sixIcon = new ImageIcon(getClass().getResource("/images/six.png"));
		ImageIcon sixIcon2 = new ImageIcon(getClass().getResource("/images/six2.png"));
		six = new JButton(sixIcon);
		six.setBorder(null);
		six.setPressedIcon(sixIcon2);
		six.setBounds(162, 536, 49, 35);
		six.setFocusable(false);
		pane.add(six);

		ImageIcon timesIcon = new ImageIcon(getClass().getResource("/images/times.png"));
		ImageIcon timesIcon2 = new ImageIcon(getClass().getResource("/images/times2.png"));
		times = new JButton(timesIcon);
		times.setBorder(null);
		times.setPressedIcon(timesIcon2);
		times.setBounds(218, 536, 49, 35);
		times.setFocusable(false);
		pane.add(times);

		ImageIcon divideIcon = new ImageIcon(getClass().getResource("/images/divide.png"));
		ImageIcon divideIcon2 = new ImageIcon(getClass().getResource("/images/divide2.png"));
		divide = new JButton(divideIcon);
		divide.setBorder(null);
		divide.setPressedIcon(divideIcon2);
		divide.setBounds(272, 537, 48, 34);
		divide.setFocusable(false);
		pane.add(divide);

		ImageIcon oneIcon = new ImageIcon(getClass().getResource("/images/one.png"));
		ImageIcon oneIcon2 = new ImageIcon(getClass().getResource("/images/one2.png"));
		one = new JButton(oneIcon);
		one.setBorder(null);
		one.setPressedIcon(oneIcon2);
		one.setBounds(49, 585, 48, 34);
		one.setFocusable(false);
		pane.add(one);

		ImageIcon twoIcon = new ImageIcon(getClass().getResource("/images/two.png"));
		ImageIcon twoIcon2 = new ImageIcon(getClass().getResource("/images/two2.png"));
		two = new JButton(twoIcon);
		two.setBorder(null);
		two.setPressedIcon(twoIcon2);
		two.setBounds(105, 584, 48, 34);
		two.setFocusable(false);
		pane.add(two);

		ImageIcon threeIcon = new ImageIcon(getClass().getResource("/images/three.png"));
		ImageIcon threeIcon2 = new ImageIcon(getClass().getResource("/images/three2.png"));
		three = new JButton(threeIcon);
		three.setBorder(null);
		three.setPressedIcon(threeIcon2);
		three.setBounds(160, 584, 48, 34);
		three.setFocusable(false);
		pane.add(three);

		ImageIcon plusIcon = new ImageIcon(getClass().getResource("/images/plus.png"));
		ImageIcon plusIcon2 = new ImageIcon(getClass().getResource("/images/plus2.png"));
		plus = new JButton(plusIcon);
		plus.setBorder(null);
		plus.setPressedIcon(plusIcon2);
		plus.setBounds(218, 586, 45, 34);
		plus.setFocusable(false);
		pane.add(plus);

		ImageIcon minusIcon = new ImageIcon(getClass().getResource("/images/minus.png"));
		ImageIcon minusIcon2 = new ImageIcon(getClass().getResource("/images/minus2.png"));
		minus = new JButton(minusIcon);
		minus.setBorder(null);
		minus.setPressedIcon(minusIcon2);
		minus.setBounds(273, 586, 45, 34);
		minus.setFocusable(false);
		pane.add(minus);

		ImageIcon zeroIcon = new ImageIcon(getClass().getResource("/images/zero.png"));
		ImageIcon zeroIcon2 = new ImageIcon(getClass().getResource("/images/zero2.png"));
		zero = new JButton(zeroIcon);
		zero.setBorder(null);
		zero.setPressedIcon(zeroIcon2);
		zero.setBounds(49, 632, 48, 34);
		zero.setFocusable(false);
		pane.add(zero);

		ImageIcon decimalIcon = new ImageIcon(getClass().getResource("/images/decimal.png"));
		ImageIcon decimalIcon2 = new ImageIcon(getClass().getResource("/images/decimal2.png"));
		decimal = new JButton(decimalIcon);
		decimal.setBorder(null);
		decimal.setPressedIcon(decimalIcon2);
		decimal.setBounds(105, 634, 48, 33);
		decimal.setFocusable(false);
		pane.add(decimal);

		ImageIcon baseTenIcon = new ImageIcon(getClass().getResource("/images/baseTen.png"));
		ImageIcon baseTenIcon2 = new ImageIcon(getClass().getResource("/images/baseTen2.png"));
		baseTen = new JButton(baseTenIcon);
		baseTen.setBorder(null);
		baseTen.setPressedIcon(baseTenIcon2);
		baseTen.setBounds(160, 635, 48, 33);
		baseTen.setFocusable(false);
		pane.add(baseTen);

		ImageIcon ansIcon = new ImageIcon(getClass().getResource("/images/ans.png"));
		ImageIcon ansIcon2 = new ImageIcon(getClass().getResource("/images/ans2.png"));
		ans = new JButton(ansIcon);
		ans.setBorder(null);
		ans.setPressedIcon(ansIcon2);
		ans.setBounds(215, 635, 48, 33);
		ans.setFocusable(false);
		pane.add(ans);

		ImageIcon equalsIcon = new ImageIcon(getClass().getResource("/images/equals.png"));
		ImageIcon equalsIcon2 = new ImageIcon(getClass().getResource("/images/equals2.png"));
		equals = new JButton(equalsIcon);
		equals.setBorder(null);
		equals.setPressedIcon(equalsIcon2);
		equals.setBounds(272, 635, 48, 33);
		equals.setFocusable(false);
		pane.add(equals);

		
		text = new JTextArea("");
		text.setBounds(62, 140, 257, 30);
		text.setFont(new Font("Serif", Font.BOLD, 24));
		text.setBorder(null);
		text.setEditable(false);
		text.setOpaque(false);
		text.addKeyListener(this);
		DefaultCaret caret = (DefaultCaret)text.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		JScrollPane sp = new JScrollPane(text);
		sp.setBounds(62, 140, 257, 30);
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(null);
		pane.add(sp);

		text2 = new JTextArea("");
		text2.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		text2.setBounds(59, 173, 260, 50);
		text2.setFont(new Font("Serif", Font.BOLD, 36));
		text2.setBorder(null);
		text2.setEditable(false);
		text2.setOpaque(false);
		pane.add(text2);
		
		text3 = new JTextField("");
		text3.setHorizontalAlignment(JTextField.RIGHT);
		text3.setBounds(219, 124, 30, 15);
		Color clr3 = new Color(6,10,58);
		text3.setForeground(clr3);
		text3.setFont(new Font("Serif", Font.BOLD, 10));
		text3.setBorder(null);
		text3.setEditable(false);
		text3.setOpaque(false);
		pane.add(text3);

		text4 = new JTextField("");
		Color clr = new Color(204, 234, 198);
		text4.setBackground(clr);
		text4.setOpaque(true);
		text4.setBounds(62, 127, 257, 12);
		text4.setBorder(null);
		pane.add(text4);
		
		hideCover.addActionListener(this);
		zero.addActionListener(this);
		one.addActionListener(this);
		two.addActionListener(this);
		three.addActionListener(this);
		four.addActionListener(this);
		five.addActionListener(this);
		six.addActionListener(this);
		seven.addActionListener(this);
		eight.addActionListener(this);
		nine.addActionListener(this);
		decimal.addActionListener(this);
		on.addActionListener(this);
		ac.addActionListener(this);
		del.addActionListener(this);
		plus.addActionListener(this);
		minus.addActionListener(this);
		times.addActionListener(this);
		divide.addActionListener(this);
		equals.addActionListener(this);
		sin.addActionListener(this);
		cos.addActionListener(this);
		tan.addActionListener(this);
		negative.addActionListener(this);
		openP.addActionListener(this);
		closeP.addActionListener(this);
		solarPanel.addMouseListener(this);
		xCube.addActionListener(this);
		square.addActionListener(this);
		log.addActionListener(this);
		xInverse.addActionListener(this);
		naturalLog.addActionListener(this);
		squareroot.addActionListener(this);
		abs.addActionListener(this);
		baseTen.addActionListener(this);
		exponentInput.addActionListener(this);
		shift.addActionListener(this);
		arrowLeft.addActionListener(this);
		arrowRight.addActionListener(this);
		alpha.addActionListener(this);
		mPlus.addActionListener(this);
		ans.addActionListener(this);
		logStat.addActionListener(this);
		pane.setOpaque(false);
		return pane;
	}

	public JPanel getCover() {

		JPanel panel = new JPanel();
		ImageIcon cover = new ImageIcon(getClass().getResource("/images/cover.jpg"));
		JLabel label = new JLabel(cover);
		panel.add(label);

		return panel;

	}

	int posX = 0;
	int posY = 0;
	JFrame cover;

	public void getBackGroundImage() {

		cover = new JFrame("cover");
		cover.setUndecorated(true);
		cover.setSize(360, 750);
		cover.setContentPane(getCover());
		cover.setResizable(false);
		cover.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cover.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				posX = e.getX();
				posY = e.getY();
			}
		});

		cover.addMouseMotionListener(new MouseAdapter() {
			public void mouseDragged(MouseEvent evt) {
				// sets frame position when mouse dragged
				cover.setLocation(evt.getXOnScreen() - posX, evt.getYOnScreen()
						- posY);

			}
		});

		frame = new JFrame("Scientific Calculator");
		
		Background bg = new Background();
		frame.setContentPane(bg);
		frame.setGlassPane(setButtons());
		frame.getGlassPane().setVisible(true);
		frame.getGlassPane().addKeyListener(this);
		frame.pack();
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		cover.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setFocusable(true);
		frame.addKeyListener(this);
		cover.addKeyListener(this);
		this.frame.getGlassPane().addKeyListener(this);
		this.cover.addKeyListener(this);
		this.text.addKeyListener(this);
		this.text2.addKeyListener(this);
		this.text3.addKeyListener(this);
		this.text4.addKeyListener(this);
		cover.setVisible(true);
	}
	
	public void compute() throws ScriptException{
		boolean memPlus = false;
		boolean memMinus = false;
		String equation = text.getText();
		equation = equation.replaceAll("x", "*");
		equation = equation.replace("\u00F7", "/");
		equation = equation.replace("\u00B2", "rt(2)");
		equation = equation.replace("\u00B3", "rt(3)");
		equation = equation.replaceAll("\u03C0", "(3.1415926535898)");
		equation = equation.replaceAll("ANS", "(" + answer + ")");
		if(equation.contains("M\u208A"))
			memPlus = true;
		equation = equation.replaceAll("M\u208A", "");
		if(equation.contains("M\u208B"))
			memMinus = true;
		equation = equation.replaceAll("M\u208B", "");
		for(int j = 0; j<equation.length();j++){
			if(equation.charAt(j)=='M'){
				if(j!=equation.length()-1){
					if(equation.charAt(j+1)!='\u208A'&&equation.charAt(j+1)!='\u208B'){
						equation = equation.substring(0,j) + "(" + memory + ")" + equation.substring(j+1,equation.length());
						System.out.println(equation);
					}
				}else{
					equation = equation.substring(0,equation.length()-1) + "(" + memory + ")";
				}
		
			}
		
		}
		
		
		int balancer = 0;
		for(int i = 0; i<equation.length(); i++){
			if(equation.charAt(i)=='(')
				balancer++;
			else if(equation.charAt(i)==')')
				balancer--;
		}
		
		if(balancer==0){
			
		}else if(balancer>0){
			for(int i = 0; i<balancer;i++){
				equation = equation + ")";
			}
		}else{
			for(int i = balancer; i<0;i++){
				equation = "(" + equation;
			}
		}
		
		
		for(int i = 0; i<equation.length();i++){
			
			if(equation.charAt(i)=='\u207B'){
				if(equation.charAt(i-1)!='n'&&equation.charAt(i-1)!='s'){
					String tempSub = equation.substring(0, i);
					String tempSub2 = equation.substring(i+2 , equation.length());
					equation = tempSub + "rt(-1)" + tempSub2;
				}
			}
			if(equation.charAt(i)=='^'){
				if(equation.charAt(i-1)!='n'&&equation.charAt(i-1)!='s'&&equation.charAt(i-1)!='e'){
					String tempSub = equation.substring(0, i);
					String tempSub2 = equation.substring(i+2 , equation.length());
					equation = tempSub + "rt(" + tempSub2;
				}
				
				
			}
			
		}
		
		
		
		for(int i = 0; i<equation.length();i++){
			
			if(equation.charAt(i)=='('||equation.charAt(i)=='c'||equation.charAt(i)=='t'||equation.charAt(i)=='s'||equation.charAt(i)=='l'||equation.charAt(i)=='\u221A'||equation.charAt(i)=='S'){	
				
				if(i!=0){

					if(equation.charAt(i-1)=='0'||equation.charAt(i-1)=='1'||equation.charAt(i-1)=='2'||equation.charAt(i-1)=='3'||equation.charAt(i-1)=='4'||equation.charAt(i-1)=='5'||equation.charAt(i-1)=='6'||equation.charAt(i-1)=='7'||equation.charAt(i-1)=='8'||equation.charAt(i-1)=='9'){
						equation = equation.substring(0,i) + "*" + equation.substring(i,equation.length());
					}
				}
				
			}
		}
		
		String temp = equation;
		String substr = equation;
		int pCtr = 1;
		int ctr = 0;
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("JavaScript");
	
		while(equation.contains("cos")||equation.contains("sin")||equation.contains("tan")||equation.contains("ln")||equation.contains("log")||equation.contains("e^(")||equation.contains("\u221A")||equation.contains("ABS")||equation.contains("sin\u207B\u00B9")||equation.contains("cos\u207B\u00B9")||equation.contains("tan\u207B\u00B9")||equation.contains("rt")||equation.contains("log[")){

			temp = equation;
			if(temp.contains("(rt("))
				break;
				if(equation.contains("cos(")){	
					substr = temp.substring(temp.indexOf("cos(")+4, temp.length());
					while(temp.contains("cos")){
						if(substr.contains("cos")){
							String temp2 = substr.substring(substr.indexOf("cos(")+4, substr.length());
							substr = temp2;
						}else if(!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
							Double a = Math.cos(((Double)(engine.eval(substr))));
							substr = "cos(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of cos
					
				}//end of if
				temp =equation;
		
				if(equation.contains("sin(")){
					substr = temp.substring(temp.indexOf("sin(")+4, temp.length());
					while(temp.contains("sin")){
						if(substr.contains("sin")){
							String temp2 = substr.substring(substr.indexOf("sin(")+4, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
							Double a = Math.sin((Double)(engine.eval(substr)));
							substr = "sin(" + substr + ")";
							equation = equation.replace(substr, "(" +a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of sin
					
				}//end of sin
				
				temp =equation;
				if(equation.contains("tan(")){
					substr = temp.substring(temp.indexOf("tan(")+4, temp.length());
					while(temp.contains("tan")){
						if(substr.contains("tan")){
							String temp2 = substr.substring(substr.indexOf("tan(")+4, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = Math.tan((Double)(engine.eval(substr)));
							substr = "tan(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of tan
					
				}//end of tan
				
				temp = equation;
				if(equation.contains("ln(")){
					substr = temp.substring(temp.indexOf("ln(")+3, temp.length());
					while(temp.contains("ln")){
						if(substr.contains("ln")){
							String temp2 = substr.substring(substr.indexOf("ln(")+3, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = Math.log((Double)(engine.eval(substr)));
							substr = "ln(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of ln
					
				}//end of ln
				
				temp = equation;
				if(equation.contains("log(")){
					substr = temp.substring(temp.indexOf("log(")+4, temp.length());
					while(temp.contains("log")){
						if(substr.contains("log")){
							String temp2 = substr.substring(substr.indexOf("log(")+4, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.log((Double)(engine.eval(substr)))/Math.log(10));
							substr = "log(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of log
					
				}//end of log
				
				if(equation.contains("log[")){
					substr = temp.substring(temp.indexOf("log[")+4, temp.length());
					while(temp.contains("log[")){
						if(substr.contains("log[")){
							String temp2 = substr.substring(substr.indexOf("log[")+4, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log(")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='[')
									pCtr++;
								else if(substr.charAt(ctr)==']')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
							String base = substr.substring(0,substr.indexOf(","));
							String n = substr.substring(substr.indexOf(",")+1, substr.length());
							Double a = (Math.log((Double)(engine.eval(n)))/Math.log((Double)(engine.eval(base))));
							substr = "log[" + substr + "]";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of baselog
					
				}//end of baselog
				
				temp = equation;
				if(equation.contains("e^")){
					substr = temp.substring(temp.indexOf("e^(")+3, temp.length());
					while(temp.contains("e^")){
						if(substr.contains("e^")){
							String temp2 = substr.substring(substr.indexOf("e^(")+3, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("\u221A")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.pow(Math.E, (Double)(engine.eval(substr))));
							substr = "e^(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of e
					
				}//end of e

				temp = equation;
				if(equation.contains("\u221A")){
					substr = temp.substring(temp.indexOf("\u221A(")+2, temp.length());
					while(temp.contains("\u221A")){
						if(substr.contains("\u221A")){
							String temp2 = substr.substring(substr.indexOf("\u221A(")+2, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.sqrt((Double)(engine.eval(substr))));
							substr = "\u221A(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of square root
					
				}//end of squareroot
				temp = equation;
				if(equation.contains("ABS")){
					substr = temp.substring(temp.indexOf("ABS(")+4, temp.length());
					while(temp.contains("ABS")){
						if(substr.contains("ABS")){
							String temp2 = substr.substring(substr.indexOf("ABS(")+4, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;									
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.abs((Double)(engine.eval(substr))));
							substr = "ABS(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of ABS
					
				}//end of ABS
				temp = equation;
				if(equation.contains("cos\u207B\u00B9")){
					substr = temp.substring(temp.indexOf("cos\u207B\u00B9(")+6, temp.length());
					while(temp.contains("cos\u207B\u00B9")){
						if(substr.contains("cos\u207B\u00B9")){
							String temp2 = substr.substring(substr.indexOf("cos\u207B\u00B9(")+6, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("ABS")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;									
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.acos((Double)(engine.eval(substr))));
							substr = "cos\u207B\u00B9(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of acos
					
				}//end of acos
				temp = equation;
				if(equation.contains("sin\u207B\u00B9")){
					substr = temp.substring(temp.indexOf("sin\u207B\u00B9(")+6, temp.length());
					while(temp.contains("sin\u207B\u00B9")){
						if(substr.contains("sin\u207B\u00B9")){
							String temp2 = substr.substring(substr.indexOf("sin\u207B\u00B9(")+6, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("ABS")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;									
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.asin((Double)(engine.eval(substr))));
							substr = "sin\u207B\u00B9(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of asin
					
				}//end of asin
				temp = equation;
				if(equation.contains("tan\u207B\u00B9")){
					substr = temp.substring(temp.indexOf("tan\u207B\u00B9(")+6, temp.length());
					while(temp.contains("tan\u207B\u00B9")){
						if(substr.contains("tan\u207B\u00B9")){
							String temp2 = substr.substring(substr.indexOf("tan\u207B\u00B9(")+6, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("rt")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;									
							}
							substr = substr.substring(0, ctr-1);
				
							Double a = (Math.atan((Double)(engine.eval(substr))));
							substr = "tan\u207B\u00B9(" + substr + ")";
							equation = equation.replace(substr, "(" + a.toString()+ ")");
							temp = "";
							
						}else{
							temp = "";
					
						}
						
					}//end of atan
					
				}//end of atan
				temp = equation;
				String substr2;
				if(equation.contains("rt(")){
					substr = temp.substring(temp.indexOf("rt(")+3, temp.length());
					substr2 = temp.substring(0,temp.indexOf("rt("));
					pCtr = 0;
					ctr = 0;
					if(substr2.charAt(substr2.length()-1)==')'){
						do{
							if(substr2.charAt(substr2.length()-1 - ctr)==')')
								pCtr++;
							else if(substr2.charAt(substr2.length() -1 - ctr)=='(')
								pCtr--;
							ctr++;	
						}while(pCtr!=0);
						substr2 = substr2.substring(substr2.length()-ctr+1, substr2.length()-1);
					}
					
					
				if(!substr2.contains("cos")&&!substr2.contains("sin")&&!substr2.contains("tan")&&!substr2.contains("ln")&&!substr2.contains("log")&&!substr2.contains("e^(")&&!substr2.contains("\u221A")&&!substr2.contains("cos\u207B\u00B9")&&!substr2.contains("ABS")&&!substr2.contains("sin\u207B\u00B9")&&!substr2.contains("tan\u207B\u00B9")&&!substr.contains("log[")){
					
					while(temp.contains("rt")){
						if(substr.contains("rt")){
							String temp2 = substr.substring(substr.indexOf("rt(")+3, substr.length());
							substr = temp2;
						}else if(!substr.contains("cos")&&!substr.contains("sin")&&!substr.contains("tan")&&!substr.contains("ln")&&!substr.contains("log")&&!substr.contains("e^(")&&!substr.contains("\u221A")&&!substr.contains("cos\u207B\u00B9")&&!substr.contains("ABS")&&!substr.contains("sin\u207B\u00B9")&&!substr.contains("tan\u207B\u00B9")&&!substr.contains("log[")){
							pCtr = 1;
							ctr = 0;
							while(pCtr!=0){
								if(substr.charAt(ctr)=='(')
									pCtr++;
								else if(substr.charAt(ctr)==')')
									pCtr--;
								ctr++;									
							}
							substr = substr.substring(0, ctr-1);
							Double b = (Double)(engine.eval(substr2));
							Double a = (Math.pow(b, (Double)(engine.eval(substr))));
							substr = "rt(" + substr + ")";
							equation = equation.replace(substr, "");
							equation = equation.replace(substr2, "(" + a.toString()+ ")");
							temp = "";
									
						}else{
							temp = "";
					
						}
						
					}//end of rt
				}	
			}//end of rt
				
		}//end of while
			

			

		
			for(int i = 0; i<equation.length();i++){
				if(equation.charAt(i)!='+'&&equation.charAt(i)!='-'&&equation.charAt(i)!='*'&&equation.charAt(i)!='/'&&equation.charAt(i)!='('){
					
					if(i!=equation.length()-1){
						if(equation.charAt(i+1)=='('){
							equation = equation.substring(0,i+1) + "*" + equation.substring(i+1,equation.length());
						}
					}
					
				}
				if(equation.charAt(i)==')'){
					
					if(i!=equation.length()-1){
						
						if(equation.charAt(i+1)!='+'&&equation.charAt(i+1)!='-'&&equation.charAt(i+1)!='*'&&equation.charAt(i+1)!='/'&&equation.charAt(i+1)!=')'){
							equation = equation.substring(0,i+1) + "*" + equation.substring(i+1,equation.length());
							System.out.println(equation);
						}
					}
					
				}
				
			}
			
			
			Double z = (Double) engine.eval(equation);
			equation = z.toString();
			
			if(equation.length()>15){
				equation = equation.substring(0,15);
			}
			
			if(equation.charAt(0)=='-'){
				equation = equation.substring(1, equation.length()) + "-";
			}
			text2.setText(equation);
			answer = equation;
			if(memPlus){
				memory = ((Double) engine.eval(memory +"+"+equation)).toString();
			}
			if(memMinus){
				memory = ((Double) engine.eval(memory +"-"+equation)).toString();
			}
		}
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SciCal start = new SciCal();
		start.getBackGroundImage();	
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == hideCover) {
			if (cover.isVisible())
				cover.setVisible(false);
			else
				cover.setVisible(true);
		}
		if (isOn) {

			if (e.getSource() == ac&&!isShift&&!isAlpha) {
				text2.setText("");
				text.setText("");
				checker = false;
				isZero = false;
				isAlpha = false;
				isShift = false;
			}
			if (e.getSource() == zero&&!isShift&&!isAlpha) {
				text.insert("0", text.getCaretPosition());
			}

			if (e.getSource() == decimal&&!isShift&&!isAlpha) {
				text.insert(".", text.getCaretPosition());
			}
			if (e.getSource() == one&&!isShift&&!isAlpha) {
				text.insert("1", text.getCaretPosition());
			}
			if (e.getSource() == two&&!isShift&&!isAlpha) {
				text.insert("2", text.getCaretPosition());
			}
			if (e.getSource() == three&&!isShift&&!isAlpha) {
				text.insert("3", text.getCaretPosition());
			}
			if (e.getSource() == four&&!isShift&&!isAlpha) {
				text.insert("4", text.getCaretPosition());
			}
			if (e.getSource() == five&&!isShift&&!isAlpha) {
				text.insert("5", text.getCaretPosition());
			}
			if (e.getSource() == six&&!isShift&&!isAlpha) {
				text.insert("6", text.getCaretPosition());
			}
			if (e.getSource() == seven&&!isShift&&!isAlpha) {
				text.insert("7", text.getCaretPosition());
			}
			if (e.getSource() == eight&&!isShift&&!isAlpha) {
				text.insert("8", text.getCaretPosition());
			}
			if (e.getSource() == nine&&!isShift&&!isAlpha) {
				text.insert("9", text.getCaretPosition());
			}
			if (e.getSource() == del&&!isShift&&!isAlpha) {
					if(text.getCaretPosition()!=0)
					text.replaceRange("",text.getCaretPosition()-1 , text.getCaretPosition());
			}
			if (e.getSource() == plus&&!isShift&&!isAlpha) {
				text.insert("+", text.getCaretPosition());
			}
			
			if (e.getSource() == minus&&!isShift&&!isAlpha) {
				text.insert("-", text.getCaretPosition());
			}
			if (e.getSource() == times&&!isShift&&!isAlpha) {
				text.insert("x", text.getCaretPosition());
			}
			if (e.getSource() == divide&&!isShift&&!isAlpha) {
				text.insert("\u00F7", text.getCaretPosition());
			}
			if (e.getSource() == sin&&!isShift&&!isAlpha) {
				text.insert("sin(", text.getCaretPosition());
			}
			if (e.getSource() == cos&&!isShift&&!isAlpha) {
				text.insert("cos(", text.getCaretPosition());
			}
			if (e.getSource() == tan&&!isShift&&!isAlpha) {
				text.insert("tan(", text.getCaretPosition());
			}
			if (e.getSource() == baseTen&&!isShift&&!isAlpha) {
				text.insert("10^(", text.getCaretPosition());
			}
			if (e.getSource() == exponentInput&&!isShift&&!isAlpha) {
				text.insert("^(", text.getCaretPosition());
			}
			if (e.getSource() == log&&!isShift&&!isAlpha) {
				text.insert("log(", text.getCaretPosition());
			}
			if (e.getSource() == naturalLog&&!isShift&&!isAlpha) {
				text.insert("ln(", text.getCaretPosition());
			}
			if (e.getSource() == abs&&!isShift&&!isAlpha) {
				text.insert("ABS(", text.getCaretPosition());
			}
			if (e.getSource() == negative&&!isShift&&!isAlpha) {
				text.insert("(-", text.getCaretPosition());
			}
			if (e.getSource() == openP&&!isShift&&!isAlpha) {
				text.insert("(", text.getCaretPosition());
			}
			if (e.getSource() == closeP&&!isShift&&!isAlpha) {
				text.insert(")", text.getCaretPosition());
			}

			if (e.getSource() == square&&!isShift&&!isAlpha) {
				text.insert("\u00B2", text.getCaretPosition());
			}
			if (e.getSource() == xCube&&!isShift&&!isAlpha) {
				text.insert("\u00B3", text.getCaretPosition());
			}
			if (e.getSource() == squareroot&&!isShift&&!isAlpha) {
				text.insert("\u221A(", text.getCaretPosition());
			}
			if (e.getSource() == xInverse&&!isShift&&!isAlpha) {
				text.insert("\u207B" + "\u00B9", text.getCaretPosition());
			}
			if(e.getSource() == arrowLeft){
				if(text.getCaretPosition()!=0)
					text.setCaretPosition(text.getCaretPosition()-1);
			}
			if(e.getSource() == arrowRight){
				if(text.getCaretPosition()!=text.getText().length())
					text.setCaretPosition(text.getCaretPosition()+1);
			}
			if(e.getSource() == mPlus&&!isShift&&!isAlpha){
				text.insert("M\u208A", text.getCaretPosition());
			}
			if(e.getSource() == mPlus&&!isAlpha&&isShift){
				text.insert("M\u208B", text.getCaretPosition());
				isShift = false;
			}
			if(e.getSource() == mPlus&&!isShift&&isAlpha){
				text.insert("M", text.getCaretPosition());
				isAlpha = false;
			}
			if(e.getSource() == ans&&!isShift&&!isAlpha){
				
				text.insert("ANS", text.getCaretPosition());
				
			}
			if(e.getSource()==logStat&&!isShift&&!isAlpha){
				text.insert("log[,]", text.getCaretPosition());
			}
			if(e.getSource() == shift){
				
				if(isShift){
					isShift = false;
					text3.setText("");
				}else{
					isShift = true;
					isAlpha = false;
					text3.setText("Shift");
				}
				
			}
			if(e.getSource() == alpha){
				
				if(isAlpha){
					isAlpha = false;
					text3.setText("");
				}else{
					isShift = false;
					isAlpha = true;
					text3.setText("Alpha");
				}
				
			}
			if(e.getSource() == ac &&isShift&&!isAlpha){
				text4.setOpaque(true);
				text.getCaret().setVisible(false);
				text.setText("");
				text2.setText("");
				text3.setText("");
				checker = false;
				isShift = false;
				isZero = false;
				isOn = false;
				isAlpha = false;
				memory = "0";
				answer = "0";
				System.exit(0);
			}
			if(e.getSource()==baseTen && isShift&&!isAlpha){
				text.insert("\u03C0", text.getCaretPosition());
				isShift = false;
			}
			if (e.getSource() == sin&&isShift&&!isAlpha) {
				text.insert("sin\u207B\u00B9(", text.getCaretPosition());
				isShift = false;
			}
			
			if (e.getSource() == cos&&isShift&&!isAlpha) {
				text.insert("cos\u207B\u00B9(", text.getCaretPosition());
				isShift = false;
			}
			if (e.getSource() == tan&&isShift&&!isAlpha) {
				text.insert("tan\u207B\u00B9(", text.getCaretPosition());
				isShift = false;
			}
			
			if (e.getSource() == naturalLog&&isShift&&!isAlpha) {
				text.insert("e^(", text.getCaretPosition());
				isShift = false;
			}
			if(e.getSource()==equals&&!text.getText().contains("=")){
				try {
					compute();
				} catch (Exception e1) {
					text2.setText("Syntax Error");
					text.setText("Press 'on' to continue");
					checker = false;
					isZero = false;
					isOn = false;
					isShift = false;
					isAlpha = false;
					e1.printStackTrace();
				}
			}
			
			
		}

		if (e.getSource() == on) {

			if (!isOn) {
				isOn = true;
				text3.setText("");
				text.setText("");
				text2.setText("");
				text4.setOpaque(false);
				text.repaint();
				checker = false;
				isZero = false;
				isShift = false;
				isAlpha = false;
				text.getCaret().setVisible(true);
			} else {
				text.setText("");
				checker = false;
				isZero = false;
				isShift = false;
				isAlpha = false;
				text3.setText("");	
				text2.setText("");
			}

		}

}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {

		if (e.getSource() == solarPanel) {
			if (isOn) {
				background = new Background();
				ImageIcon icon = new ImageIcon(getClass().getResource("/images/calculator2.jpg"));
				background.bg = icon.getImage();
				frame.setContentPane(background);
				frame.revalidate();
			}

		}

	}

	@Override
	public void mouseExited(MouseEvent e) {
		if (isOn) {
			background = new Background();
			ImageIcon icon = new ImageIcon(getClass().getResource("/images/calculator.jpg"));
			background.bg = icon.getImage();
			frame.setContentPane(background);
			frame.revalidate();
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		
		if(isOn){
			if(key==KeyEvent.VK_0){
				text.insert("0", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_1){
				text.insert("1", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_2){
				text.insert("2", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_3){
				text.insert("3", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_4){
				text.insert("4", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_5){
				text.insert("5", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_6){
				text.insert("6", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_7){
				text.insert("7", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_8){
				text.insert("8", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_9){
				text.insert("9", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F1){
				text.insert("(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F2){
				text.insert(")", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F3){
				text.insert("^(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F4){
				text.insert("sin(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F5){
				text.insert("cos(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F6){
				text.insert("tan(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F7){
				text.insert("log(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F8){
				text.insert("ln(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F9){
				text.insert("e^(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F10){
				text.insert("sin\u207B\u00B9(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F11){
				text.insert("cos\u207B\u00B9(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F12){
				text.insert("tan\u207B\u00B9(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_Q){
				text.insert("+", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_W){
				text.insert("-", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_E){
				text.insert("x", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_R){
				text.insert("\u00F7", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_T){
				text.insert("M", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_U){
				text.insert("M+", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_I){
				text.insert("M-", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_O){
				text.insert("10^(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_P){
				text.insert("\u221A(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_A){
				text.insert("\u00B2", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_S){
				text.insert("\u00B3", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_D){
				text.insert("\u00B9", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_F){
				text.insert("log[,]", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_G){
				text.insert("\u03C0", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_H){
				text.insert("ABS(", text.getCaretPosition());
			}
			if(key==KeyEvent.VK_SPACE){
				text2.setText("");
				text.setText("");
				checker = false;
				isZero = false;
				isAlpha = false;
				isShift = false;
			}
			
				
			if(key==KeyEvent.VK_LEFT){
				if(text.getCaretPosition()!=0)
					text.setCaretPosition(text.getCaretPosition()-1);
			}
			if(key==KeyEvent.VK_RIGHT){
				if(text.getCaretPosition()!=text.getText().length())
					text.setCaretPosition(text.getCaretPosition()+1);
			}
			if(key==KeyEvent.VK_BACK_SPACE){
				if(text.getCaretPosition()!=0)
					text.replaceRange("",text.getCaretPosition()-1 , text.getCaretPosition());
			}
			
			
			
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {

		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		int key = e.getKeyCode();
		
		
	}

}
