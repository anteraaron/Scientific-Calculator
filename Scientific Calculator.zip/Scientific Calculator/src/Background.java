import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.*;


public class Background extends JPanel{
	
	private static final long serialVersionUID = 1L;
	Image bg;
	
	public Background(){
		
		ImageIcon icon = new ImageIcon(getClass().getResource("/images/calculator.jpg"));
		bg = icon.getImage();
		setPreferredSize(new Dimension(360,700));
		
		
	}
	
	public void paint(Graphics g) {
	    super.paint(g);
	    g.drawImage(bg, 10, 10, this); 
	    repaint();
	 
	}

}
